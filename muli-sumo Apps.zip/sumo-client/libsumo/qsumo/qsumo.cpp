/*
 * This file is part of the libsumo - a reverse-engineered library for
 * controlling Parrot's connected toy: Jumping Sumo
 *
 * Copyright (C) 2014 I. Loreen
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA
 */
#include <QApplication>
#include "sumo-widget.h"
#include <iostream>
#include <QCoreApplication>
#include <QKeyEvent>
/**************/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <string.h>
#include "../qsumo/sumo-widget.h"

/**************/


/******************************************  socket   *****************************************/
void error(const char *msg)
{
    perror(msg);
    exit(0);
}

/**********************************************************************************************/
int main(int argc, char *argv[])
{


/************************************************   socket   *******************************************/

    int sockfd, portno, n;
    struct sockaddr_in serv_addr;
    struct hostent *server;

    char buffer[256];
    if (argc < 3) {
       fprintf(stderr,"usage %s hostname port\n", argv[0]);
       exit(0);
    }
    portno = atoi(argv[2]);
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) 
        error("ERROR opening socket");
    server = gethostbyname(argv[1]);
    if (server == NULL) {
        fprintf(stderr,"ERROR, no such host\n");
        exit(0);
    }
    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    bcopy((char *)server->h_addr, 
         (char *)&serv_addr.sin_addr.s_addr,
         server->h_length);
    serv_addr.sin_port = htons(portno);
    if (connect(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0) 
        error("ERROR connecting");
	else{
	    system("clear");
            printf("+------------------------------------------------------------------+\n");
	        printf("| Robot  connected successfully.                                   |\n");
            printf("+------------------------------------------------------------------+\n");
	}

//send accpted message to the server  	
    bzero(buffer,256);
    char msg[256]="| New Robot <1> is connected to server.";
    n = write(sockfd, msg, strlen(msg));
    if (n < 0) 
         error("ERROR writing to socket");
/*..................................... app main ........................*/
	QApplication app(argc, argv);

	SumoWidget textEdit(sockfd);
	textEdit.show();
        app.exec();
/*..................................... app main ........................*/


        printf("Start Readint From Server ... \n");

	/*do
	{
	    printf("\n");
	    bzero(buffer,256);
	    n = read(sockfd, buffer, 255);
	    if (n < 0) 
		 error("ERROR reading from socket");
	    printf("#### Running command : %s",buffer);
		//char co=buffer[0];
	    //ExecuteCommand(&c,co-'0');
		//c.turnToBalance();
           // if (strcmp(strtok(buffer,"\n"),"kill")==0)
		//break;
	}while(1);
            printf("+------------------------------------------------------------------+\n");
	        printf("| Robot Disconnected...                                            |\n");
            printf("+------------------------------------------------------------------+\n");
*/


/******************************************************************************************************/
	return 1;
}
