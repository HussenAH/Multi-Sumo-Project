/*
 * This file is part of the libsumo - a reverse-engineered library for
 * controlling Parrot's connected toy: Jumping Sumo
 *
 * Copyright (C) 2014 I. Loreen
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA
 */
#include <control.h>
#include <image.h>
#include <unistd.h>
#include <iostream>
#define M_PI 3.14
#define FLAG 0
#define DEBUG 0
#define PROG !DEBUG
/**************/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <string.h>


/**************/
class ImageProcessing : public sumo::Image
{
public:
	void handleImage(const struct sumo::image *, const uint8_t *buffer1, size_t size)
	{
		fprintf(stderr, "received image of %zu bytes at %p\n", size, buffer1);
	}
};


void ExecuteCommand(sumo::Control* sumo , int cn)
{
	switch(cn)
	{
		case 0 :
			//makeEventManually(QEvent::KeyPress);
			break;
		case 1 :
			//makeEventManually(QEvent::KeyRelease);
			break;

		case 2 :
			sumo->flipDownsideUp();
		//	usleep(1500000);
			break;
		case 3 :
			sumo->handstandBalance();

			break;
		case 4 :
			sumo->highJump();

			break;
		case 5:
			sumo->longJump();

			break;
		case 6 :
			sumo->swing();

			break;
		case 7 :
			sumo->growingCircles();
			usleep(1500000);
			break;
                case 8 :
			sumo->slalom();
			break;
		case 9:
			sumo->tap();
			break;

		case 10 :
			sumo->quickTurnRight();

			break;
		case 11 :
			sumo->quickTurnRightLeft();

			break;
		case 12 :
			sumo->turnToBalance();
			usleep(1500000);
			break;
                case 13 :
			sumo->lookLeftAndRight();
			usleep(1500000);
			break;
		case 14:
			sumo->turnAndJump();

			break;

		case 15 :
			sumo->flipUpsideDown();

			break;
		default :

			break;
	}
}


/******************************************  socket   *****************************************/
void error(const char *msg)
{
    perror(msg);
    exit(0);
}

/**********************************************************************************************/



int main(int argc, char *argv[])
{

    sumo::Control c(new ImageProcessing);
    if (!c.open()){
      std::cout<<"connecting failed"<<std::endl;
		return EXIT_FAILURE;
       }

/************************************************   socket   *******************************************/

    int sockfd, portno, n;
    struct sockaddr_in serv_addr;
    struct hostent *server;

    char buffer[256];
    if (argc < 3) {
       fprintf(stderr,"usage %s hostname port\n", argv[0]);
       exit(0);
    }

   portno = atoi(argv[2]);
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) 
        error("ERROR opening socket");
    server = gethostbyname(argv[1]);
    if (server == NULL) {
        fprintf(stderr,"ERROR, no such host\n");
        exit(0);
    }
    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    bcopy((char *)server->h_addr, 
         (char *)&serv_addr.sin_addr.s_addr,
         server->h_length);
    serv_addr.sin_port = htons(portno);

    if (connect(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0) 
        error("ERROR connecting");
	else{
	    system("clear");
            printf("+------------------------------------------------------------------+\n");
	        printf("| Robot  connected successfully.                                   |\n");
            printf("+------------------------------------------------------------------+\n");
	}

//send accpted message to the server  	
    bzero(buffer,256);
    char msg[256]="| New Robot <1> is connected to server.";
    n = write(sockfd, msg, strlen(msg));
    if (n < 0) 
         error("ERROR writing to socket");


	do
	{
            printf("\n");
	    bzero(buffer,256);
	    n = read(sockfd, buffer, 255);
	    if (n < 0) 
		 error("ERROR reading from socket");
	    char c1=buffer[1];
	    char c10=buffer[0];
            int commandNum=(c10-'0')*10+(c1-'0');
	    printf("#### Running command : %d",commandNum);
	    ExecuteCommand(&c,commandNum);

            if (strcmp(strtok(buffer,"\n"),"kill")==0)
		break;
	}while(1);
            printf("+------------------------------------------------------------------+\n");
	        printf("| Robot Disconnected...                                            |\n");
            printf("+------------------------------------------------------------------+\n");

/******************************************************************************************************/


/*
#if FLAG

    sumo::Control dispatcher(new ImageProcessing);


    if (!dispatcher.open())
        return EXIT_FAILURE;
	for (int i = 0; i < 4; i++) {
		dispatcher.quickTurn(-M_PI/2);
		usleep(1000000);
	}

	for (int i = 0 ; i < 6; i++) {
		dispatcher.quickTurn(M_PI/3);
		usleep(1500000);
	}
#endif



#if DEBUG
    c.move(-20, 100);
//     getchar();
        usleep(1500000);

     c.move(10, 100);
 //    getchar();
        usleep(1500000);

     c.move(0, 0);
   //  getchar();

     c.move(20, 0);
     usleep(1500000);

     c.move(-20, 0);
//     getchar();
        usleep(1500000);


     c.move(0, 0);
//     getchar();
     //   usleep(1500000);
    c.slalom();
       usleep(1500000);
     c.tap();
 //    getchar();
        usleep(1500000);


     c.swing();
//     getchar();
        usleep(1500000);

     c.quickTurnRightLeft();
  //   getchar();
        usleep(1500000);
        c.move(0, 0);

     c.turnAndJump();
  //   getchar();
        usleep(1500000);

     c.turnToBalance();
//     getchar();
        usleep(1500000);

     c.slalom();
 //    getchar();
        usleep(1500000);

     c.turnToBalance();
        usleep(1500000);*/

/*	c.swing();
	c.move(10, 10);
	c.quickTurn(90);
	c.slalom();
	c.quickTurnRightLeft();
	c.turnToBalance();
    c.turnAndJump();*/



/*
        c.flipDownsideUp();
        usleep(500000);
        c.flipUpsideDown();
        usleep(1500000);
        c.quickTurn(-270);
        usleep(150000);

        c.move(-100, 0);
        usleep(1000000);
        c.move(0, 0);
        c.move(100, 0);
        usleep(1000000);
        c.move(0, 0);
#endif
#if PROG
        
        c.flipDownsideUp();
        usleep(500000);

        c.flipUpsideDown();
        usleep(1500000);

        c.quickTurn(-180);
        usleep(150000);

        c.move(50, 0);
        usleep(2000000);
        c.move(0, 0);

        c.quickTurn(90);
        usleep(2000000);

        c.move(50, 0);
        usleep(1000000);
        c.move(0, 0);  

        
        
        
        
        
        
    getchar(); //dispatcher.wait();
    c.close();
#endif
*/
   c.close();
	return EXIT_SUCCESS;
}
