/*
 * This file is part of the libsumo - a reverse-engineered library for
 * controlling Parrot's connected toy: Jumping Sumo
 *
 * Copyright (C) 2014 I. Loreen
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA
 */
#include <QApplication>
#include "sumo-widget.h"
#include <iostream>

/********************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
/********************/


void error2(const char *msg)
{
    perror(msg);
    exit(1);
}
/*******************************************************/




int startServer(int argc ,char *argv[])
{
     int sockfd, portno;//,newsockfd2;
     //socklen_t clilen;//,clilen2;
     //char buffer[256];
     struct sockaddr_in serv_addr;//, cli_addr ;//, cli_addr2;
   //  int n;


     if (argc < 2) {
         fprintf(stderr,"ERROR, no port provided\n");
         exit(1);
     }
     // create a socket
     // socket(int domain, int type0 int protocol)
     sockfd =  socket(AF_INET, SOCK_STREAM, 0);
     if (sockfd < 0)
        error2("ERROR opening socket");

     // clear address structure
     bzero((char *) &serv_addr, sizeof(serv_addr));

     portno = atoi(argv[1]);

     /* setup the host_addr structure for use in bind call */
     // server byte order
     serv_addr.sin_family = AF_INET;

     // automatically be filled with current host's IP address
     serv_addr.sin_addr.s_addr = INADDR_ANY;

     // convert short integer value for port must be converted into network byte order
     serv_addr.sin_port = htons(portno);

     // bind(int fd, struct sockaddr *local_addr, socklen_t addr_length)
     // bind() passes file descriptor, the address structure,
     // and the length of the address structure
     // This bind() call will bind  the socket to the current IP address on port, portno
     if (bind(sockfd, (struct sockaddr *) &serv_addr,
              sizeof(serv_addr)) < 0)
              error2("ERROR on binding");


	    system("clear");
            printf("+------------------------------------------------------------------+\n");
	    printf("| Server connected successfully                                    |\n");
            printf("+------------------------------------------------------------------+\n");


	return sockfd;
}



/*******************************************************/

int main(int argc, char *argv[])//int main(int argv, char **args)
{

	int sockfd=startServer(argc, argv);

	QApplication app(argc, argv);
	std::cout<<"Start Master App - Server "<<std::endl;
	SumoWidget textEdit(sockfd);
       textEdit.show();
        int ret=app.exec();
	//close(sockfd);
	return ret;

}
