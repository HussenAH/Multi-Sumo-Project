/*
 * This file is part of the libsumo - a reverse-engineered library for
 * controlling Parrot's connected toy: Jumping Sumo
 *
 * Copyright (C) 2014 I. Loreen
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA
 */
#include "sumo-widget.h"

#include <QKeyEvent>
#include <QSlider>

#include <control.h>
#include <image.h>
#include <iostream>


 int sockfd;
 int connectedRobots[100];
 int i=0;
int mod=0;
void error(const char *msg)
{
    perror(msg);
    exit(1);
}

int sendCommandToClient(int newsockfd)//,int newsockfd2)
{
    char buffer[256];
    std::cout<<"Try now..."<<std::endl;
  //  bzero(buffer,256);
   fgets(buffer,255,stdin); 
   //strcpy(buffer,"hi");
    send(newsockfd, buffer, strlen(buffer), 0);
    //send(newsockfd2, buffer, strlen(buffer), 0);
    std::cout<<"Finish..."<<std::endl;
    return strcmp(strtok(buffer,"\n"),"kill");
}

void sendToAllClients(int* client,int n,char* command)
{
    char buffer[256];
  strcpy(buffer,command);
      // send(client[mod%2], buffer, strlen(buffer), 0);
      // mod++;
  for(int j=0;j<n;j++)
     {
       send(client[j], buffer, strlen(buffer), 0);
     }
}
/*
void sendToClient(int i,,int* client ,char* command ){

       char buffer[256];
       strcpy(buffer,command);
       send(client[j], buffer, strlen(buffer), 0);

}
*/


SumoWidget::SumoWidget(int _sockfd) : accel(0), turn(0), sumo(0)
{
	sockfd=_sockfd;
	setupUi(this);
	 //   timer_id = startTimer(75);
	setFocusPolicy(Qt::StrongFocus);
}

void SumoWidget::keyPressEvent(QKeyEvent *e)
{
      if(flag==0)
	{
	    timer_id = startTimer(75);
	    std::cout<< "flag == 0" <<std::endl;
	    flag=1;
	}

	if (!e->isAutoRepeat()) {
		keys[e->key()] = true;
                std::cout<< "key Press" <<std::endl;
	char command[256]="10";
    	 std::cout<<"sending "<<command<< "..."<<std::endl;
         sendToAllClients(connectedRobots,i,command);
	}
	//QWidget::keyPressEvent(e);
}

void SumoWidget::keyReleaseEvent(QKeyEvent *e)
{
	if (!e->isAutoRepeat()) {
		keys[e->key()] = false;
                std::cout<< "Key Release"<<std::endl;
	char command[256]="01";
    	 std::cout<<"sending "<<command<< "..."<<std::endl;
         sendToAllClients(connectedRobots,i,command);
	}
	//QWidget::keyReleaseEvent(e);
}

/*void SumoWidget::makeEventManually(){
			QKeyEvent *e = new QKeyEvent( QEvent::KeyPress, Qt::Key_Up, Qt::NoModifier);
			QCoreApplication::postEvent(this, e);
			if (!e->isAutoRepeat()) {
					keys[e->key()] = true;
					std::cout<< "key Press" <<std::endl;
				}
				QWidget::keyPressEvent(e);
}*/

void SumoWidget::timerEvent(QTimerEvent *)
{
	int mod = 0;

#define ACCELERATION_CONSTANT 6
std::cout<< "timer" <<std::endl;
//makeEventManually();
	/* auto reduce speed if neither accelerating nor breaking */
	if (!keys[Qt::Key_Down] && !keys[Qt::Key_Up]) {
		mod = -(accel/ACCELERATION_CONSTANT); /* the faster we go the more we reduce speed */
		if (mod == 0 && accel)
			mod = 1 * (accel < 0 ? 1 : -1);
	}

	if (keys[Qt::Key_Up]) {
		if (accel >= 0)
			mod = ACCELERATION_CONSTANT;
		else /* breaking - we are going reverse */
			mod = ACCELERATION_CONSTANT * 2;
	}

	if (keys[Qt::Key_Down]) {
		if (accel <= 0)
			mod = -ACCELERATION_CONSTANT;
		else /* breaking */
			mod = -ACCELERATION_CONSTANT * 2;
	}

	accel += mod;

	if (accel > 127)
		accel = 127;
	if (accel < -127)
		accel = -127;

	/* turning */
#define TURN_CONSTANT 5
	mod = 0;
	if (!keys[Qt::Key_Left] && !keys[Qt::Key_Right]) {
		mod = -turn/TURN_CONSTANT * 3;


		if (abs(turn) < TURN_CONSTANT && turn)
			mod = -turn; //TURN_CONSTANT * (turn < 0 ? 1 : -1);
	}

	if (keys[Qt::Key_Left])
		mod = -TURN_CONSTANT;

	if (keys[Qt::Key_Right])
		mod = TURN_CONSTANT;

	turn += mod;
	if (turn > 32)
		turn = 32;
	if (turn < -32)
		turn = -32;

	//_speed->setValue(accel);
	//_turning->setValue(turn);
std::cout<< "move(" <<accel<<","<<turn<<")"<<std::endl;
	//sumo->move(accel, turn);
	//_batteryLevel->setValue(sumo->batteryLevel());
//	fprintf(stderr, "a: %4d, t: %4d\n", accel, turn);
}

/*
void SumoWidget::on__open_close_clicked(bool)
{
	if (sumo) {
		killTimer(timer_id);
		sumo->close();
		delete sumo; sumo = 0;
		_open_close->setText("Open");
	} else {
		sumo = new sumo::Control(new sumo::ImageMplayerPopen());//here open new client socket
		if (!sumo->open()) {
			delete sumo;
			sumo = 0;
			return;
		}
		timer_id = startTimer(75);
		//_open_close->setText("Close");
	}
}*/
void SumoWidget::on__start_server_clicked(bool)
{
     int newsockfd;
     socklen_t clilen;;
     char buffer[256];
     struct sockaddr_in  cli_addr ;
     int n;
	//_start_server->setText("Stop Server");
    listen(sockfd,5);

     // The accept() call actually accepts an incoming connection
    clilen = sizeof(cli_addr);

     // This accept() function will write the connecting client's address info
     // into the the address structure and the size of that structure is clilen.
     // The accept() returns a new socket file descriptor for the accepted connection.
     // So, the original socket file descriptor can continue to be used
     // for accepting new connections while the new socker file descriptor is used for
     // communicating with the connected client.
	    system("clear");
            printf("+------------------------------------------------------------------+\n");
	    printf("| Server connected successfully                                    |\n");
            printf("+------------------------------------------------------------------+\n");
     newsockfd = accept(sockfd,
                 (struct sockaddr *) &cli_addr, &clilen);
     printf("new sock connected successfully = %d \n",newsockfd);
     if (newsockfd < 0)
          error("ERROR on accept");
            printf("+------------------------------------------------------------------+\n");
     	    printf("| Server: got connection from  port                  |\n");
            //inet_ntoa(cli_addr.sin_addr), ntohs(cli_addr.sin_port));
            printf("+------------------------------------------------------------------+\n");

     bzero(buffer,256);
     n = read(newsockfd,buffer,255);
     if (n < 0)
	{ 
	    error("ERROR reading from socket");
	}else 
	{	

            printf("+------------------------------------------------------------------+\n");
     	    printf("%s                            |\n",buffer);
            printf("+------------------------------------------------------------------+\n");
	}
	connectedRobots[i++]= newsockfd;

return;
}



void SumoWidget::on__flipDown_clicked(bool)
{
	/*if (sumo)
		sumo->flipDownsideUp();*/
	char command[256]="02";
    	 std::cout<<"sending "<<command<< "..."<<std::endl;
         sendToAllClients(connectedRobots,i,command);
}

void SumoWidget::on__balance_clicked(bool)
{
	/*if (sumo)
		sumo->handstandBalance();*/
	char command[256]="03";
    	 std::cout<<"sending "<<command<< "..."<<std::endl;
         sendToAllClients(connectedRobots,i,command);
}

void SumoWidget::on__hijump_clicked(bool)
{
	char command[256]="04";
    	 std::cout<<"sending "<<command<< "..."<<std::endl;
         sendToAllClients(connectedRobots,i,command);
}

void SumoWidget::on__longjump_clicked(bool)
{
	/*if (sumo)
		sumo->longJump();*/
	char command[256]="05";
    	 std::cout<<"sending "<<command<< "..."<<std::endl;
         sendToAllClients(connectedRobots,i,command);
}

void SumoWidget::on__swing_clicked(bool)
{
	/*if (sumo)
		sumo->swing();*/
	char command[256]="06";
    	 std::cout<<"sending "<<command<< "..."<<std::endl;
         sendToAllClients(connectedRobots,i,command);
}

void SumoWidget::on__growingCircles_clicked(bool)
{
	/*if (sumo)
		sumo->growingCircles();*/
	char command[256]="07";
    	 std::cout<<"sending "<<command<< "..."<<std::endl;
         sendToAllClients(connectedRobots,i,command);
}

void SumoWidget::on__slalom_clicked(bool)
{
	/*if (sumo)
		sumo->slalom();*/
	char command[256]="08";
    	 std::cout<<"sending "<<command<< "..."<<std::endl;
         sendToAllClients(connectedRobots,i,command);
}

void SumoWidget::on__tap_clicked(bool)
{
	/*if (sumo)
		sumo->tap();*/
	char command[256]="09";
    	 std::cout<<"sending "<<command<< "..."<<std::endl;
         sendToAllClients(connectedRobots,i,command);
}

void SumoWidget::on__turn_clicked(bool)
{
	/*if (sumo)
		sumo->quickTurnRight();*/
	char command[256]="10";
    	 std::cout<<"sending "<<command<< "..."<<std::endl;
         sendToAllClients(connectedRobots,i,command);
}

void SumoWidget::on__turnLeftRight_clicked(bool)
{
/*	if (sumo)
		sumo->quickTurnRightLeft();*/
	char command[256]="11";
    	 std::cout<<"sending "<<command<< "..."<<std::endl;
         sendToAllClients(connectedRobots,i,command);
}

void SumoWidget::on__turnToBalance_clicked(bool)
{/*	if (sumo)
		sumo->turnToBalance();*/
	char command[256]="12";
    	 std::cout<<"sending "<<command<< "..."<<std::endl;
         sendToAllClients(connectedRobots,i,command);
}

void SumoWidget::on__watchLeftRight_clicked(bool)
{
/*	if (sumo)
		sumo->lookLeftAndRight();*/
	char command[256]="13";
    	 std::cout<<"sending "<<command<< "..."<<std::endl;
         sendToAllClients(connectedRobots,i,command);
}

void SumoWidget::on__turnAndJump_clicked(bool)
{
/*	if (sumo)
		sumo->turnAndJump();*/
	char command[256]="14";
    	 std::cout<<"sending "<<command<< "..."<<std::endl;
         sendToAllClients(connectedRobots,i,command);
}
void SumoWidget::on__flip_clicked(bool) 
{
	//if (sumo)
		//sumo->flipUpsideDown();
	char command[256]="15";
    	 std::cout<<"sending "<<command<< "..."<<std::endl;
         sendToAllClients(connectedRobots,i,command);
}

